/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ST10476195
 */
import javax.swing.*;

public class MainGUI extends JFrame {

    private JButton btnLogin;
    private JButton btnRegister;

    private Registration registration = new Registration();
    private Login login = new Login();
    private User user;  // Holds registered user

    public MainGUI() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Login & Registration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        btnLogin = new JButton("LOGIN");
        btnRegister = new JButton("REGISTER");

        btnLogin.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 16));
        btnLogin.setBackground(new java.awt.Color(0, 102, 204));
        btnLogin.setForeground(java.awt.Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setPreferredSize(new java.awt.Dimension(120, 40));

        btnRegister.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 16));
        btnRegister.setBackground(new java.awt.Color(0, 153, 51));
        btnRegister.setForeground(java.awt.Color.WHITE);
        btnRegister.setFocusPainted(false);
        btnRegister.setPreferredSize(new java.awt.Dimension(120, 40));

        btnRegister.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter Username:");
            String usernameMsg = registration.validateUsername(username);
            JOptionPane.showMessageDialog(this, usernameMsg);
            if (!"Username successfully captured.".equals(usernameMsg)) return;

            String password = JOptionPane.showInputDialog(this, "Enter Password:");
            String passwordMsg = registration.validatePassword(password);
            JOptionPane.showMessageDialog(this, passwordMsg);
            if (!"Password successfully captured.".equals(passwordMsg)) return;

            String cellPhoneNumber = JOptionPane.showInputDialog(this, "Enter Cell Phone Number (e.g. +27123456789):");
            String cellMsg = registration.validateCellPhone(cellPhoneNumber);
            JOptionPane.showMessageDialog(this, cellMsg);
            if (!"Cell phone number successfully added.".equals(cellMsg)) return;

            String firstName = JOptionPane.showInputDialog(this, "Enter First Name:");
            String lastName = JOptionPane.showInputDialog(this, "Enter Last Name:");

            user = registration.registerUser(username, password, firstName, lastName, cellPhoneNumber);
            JOptionPane.showMessageDialog(this, "User Registered Successfully!");

            // Proceed to message functionality
            new MessageGUI(user).setVisible(true);
            this.dispose(); // Close MainGUI
        });

        btnLogin.addActionListener(e -> {
            if (user == null) {
                JOptionPane.showMessageDialog(this, "No user registered yet!");
                return;
            }
            String username = JOptionPane.showInputDialog(this, "Enter Username:");
            String password = JOptionPane.showInputDialog(this, "Enter Password:");

            boolean success = login.authenticate(user, username, password);
            String message = login.getLoginStatus(user, success);
            JOptionPane.showMessageDialog(this, message);

            if (success) {
                // Proceed to message functionality
                new MessageGUI(user).setVisible(true);
                this.dispose(); // Close MainGUI
            }
        });

        JPanel panel = new JPanel();
        panel.add(btnLogin);
        panel.add(btnRegister);

        add(panel);

        // Welcome message at application startup
        JOptionPane.showMessageDialog(this, "Welcome to the Registration & Login System!");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}